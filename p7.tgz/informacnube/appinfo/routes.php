<?php

declare(strict_types=1);

return [
	'routes' => [
		['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
		['name' => 'api#me', 'url' => '/api/me', 'verb' => 'GET'],
		['name' => 'api#companies', 'url' => '/api/companies', 'verb' => 'GET'],
		['name' => 'api#createCompany', 'url' => '/api/companies', 'verb' => 'POST'],
		['name' => 'api#company', 'url' => '/api/companies/{id}', 'verb' => 'GET'],
		['name' => 'api#updateCompany', 'url' => '/api/companies/{id}', 'verb' => 'PUT'],
		['name' => 'api#addMember', 'url' => '/api/companies/{id}/members', 'verb' => 'POST'],
		['name' => 'api#updateMember', 'url' => '/api/companies/{id}/members/{uid}', 'verb' => 'PUT'],
		['name' => 'api#addArea', 'url' => '/api/companies/{id}/areas', 'verb' => 'POST'],
		['name' => 'api#trash', 'url' => '/api/companies/{id}/trash', 'verb' => 'GET'],
		['name' => 'api#restore', 'url' => '/api/companies/{id}/trash/restore', 'verb' => 'POST'],
		['name' => 'api#logo', 'url' => '/api/companies/{id}/logo', 'verb' => 'GET'],
		['name' => 'api#setLogo', 'url' => '/api/companies/{id}/logo', 'verb' => 'POST'],
		['name' => 'api#deleteLogo', 'url' => '/api/companies/{id}/logo', 'verb' => 'DELETE'],
		['name' => 'page#connect', 'url' => '/conectar', 'verb' => 'GET'],
	],
];
