<?php

declare(strict_types=1);

namespace OCA\InformacNube\Controller;

use OCA\InformacNube\Service\CompanyService;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\DataDisplayResponse;
use OCP\AppFramework\Http\JSONResponse;
use OCP\IGroupManager;
use OCP\IRequest;
use OCP\IUserSession;
use Psr\Log\LoggerInterface;

class ApiController extends Controller {
	public function __construct(
		IRequest $request,
		private CompanyService $companies,
		private IUserSession $session,
		private IGroupManager $groups,
		private LoggerInterface $logger,
	) {
		parent::__construct('informacnube', $request);
	}

	private function uid(): string {
		return $this->session->getUser()?->getUID() ?? '';
	}

	private function isAdmin(): bool {
		return $this->groups->isAdmin($this->uid());
	}

	private function body(): array {
		$p = $this->request->getParams();
		unset($p['_route'], $p['id'], $p['uid']);
		return is_array($p) ? $p : [];
	}

	/** Empresa visible para quien llama: Informac (admin) o el encargado de esa empresa. */
	private function guard(string $id): array {
		$c = $this->companies->get($id);
		if ($c === null) {
			throw new \InvalidArgumentException('Empresa no encontrada.');
		}
		if (!$this->isAdmin() && !$this->companies->isManager($c, $this->uid())) {
			throw new \DomainException('No tienes permiso para administrar esta empresa.');
		}
		return $c;
	}

	private function wrap(callable $fn): JSONResponse {
		try {
			return new JSONResponse($fn());
		} catch (\DomainException $e) {
			return new JSONResponse(['error' => $e->getMessage()], Http::STATUS_FORBIDDEN);
		} catch (\InvalidArgumentException $e) {
			return new JSONResponse(['error' => $e->getMessage()], Http::STATUS_BAD_REQUEST);
		} catch (\Throwable $e) {
			$this->logger->error('informacnube: ' . $e->getMessage(), ['exception' => $e]);
			return new JSONResponse(['error' => 'Ocurrió un error interno. Si se repite, avisa a Informac.'], Http::STATUS_INTERNAL_SERVER_ERROR);
		}
	}

	#[NoAdminRequired]
	public function me(): JSONResponse {
		return $this->wrap(function () {
			$uid = $this->uid();
			$c = $this->companies->companyForUser($uid);
			return [
				'uid' => $uid,
				'isAdmin' => $this->isAdmin(),
				'company' => $c === null ? null : [
					'id' => $c['id'],
					'name' => $c['name'],
					'initials' => $c['initials'],
					'logo' => (int)($c['logoV'] ?? 0),
					'isManager' => $this->companies->isManager($c, $uid),
				],
			];
		});
	}

	#[NoAdminRequired]
	public function companies(): JSONResponse {
		return $this->wrap(function () {
			if (!$this->isAdmin()) {
				throw new \DomainException('Solo Informac.');
			}
			return array_map(fn ($c) => $this->companies->detail($c), $this->companies->all());
		});
	}

	public function createCompany(): JSONResponse {
		return $this->wrap(function () {
			if (!$this->isAdmin()) {
				throw new \DomainException('Solo Informac.');
			}
			$r = $this->companies->createCompany($this->body());
			return ['company' => $this->companies->detail($r['company']), 'warning' => $r['warning']];
		});
	}

	#[NoAdminRequired]
	public function company(string $id): JSONResponse {
		return $this->wrap(fn () => $this->companies->detail($this->guard($id)) + ['canEditPlan' => $this->isAdmin()]);
	}

	public function updateCompany(string $id): JSONResponse {
		return $this->wrap(function () use ($id) {
			if (!$this->isAdmin()) {
				throw new \DomainException('Solo Informac puede cambiar el plan.');
			}
			$c = $this->companies->updateCompany($this->guard($id), $this->body());
			return $this->companies->detail($c);
		});
	}

	#[NoAdminRequired]
	public function addMember(string $id): JSONResponse {
		return $this->wrap(function () use ($id) {
			$r = $this->companies->addMember($this->guard($id), $this->body());
			return ['company' => $this->companies->detail($this->companies->get($id)), 'warning' => $r['warning']];
		});
	}

	#[NoAdminRequired]
	public function updateMember(string $id, string $uid): JSONResponse {
		return $this->wrap(function () use ($id, $uid) {
			$c = $this->companies->updateMember($this->guard($id), $uid, $this->body(), $this->uid(), $this->isAdmin());
			return $this->companies->detail($c);
		});
	}

	#[NoAdminRequired]
	public function trash(string $id): JSONResponse {
		return $this->wrap(fn () => $this->companies->trashList($this->guard($id)));
	}

	#[NoAdminRequired]
	public function restore(string $id): JSONResponse {
		return $this->wrap(function () use ($id) {
			$this->companies->trashRestore($this->guard($id), (string)($this->body()['name'] ?? ''));
			return ['ok' => true];
		});
	}

	#[NoAdminRequired]
	public function addArea(string $id): JSONResponse {
		return $this->wrap(function () use ($id) {
			$c = $this->companies->addArea($this->guard($id), (string)($this->body()['name'] ?? ''));
			return $this->companies->detail($c);
		});
	}

	/** Logo de la empresa: lo ven Informac y las personas de esa empresa (barra superior). */
	#[NoAdminRequired]
	#[NoCSRFRequired]
	public function logo(string $id): Http\Response {
		$c = $this->companies->get($id);
		if ($c === null || (!$this->isAdmin() && !$this->companies->isMember($c, $this->uid()))) {
			return new JSONResponse([], Http::STATUS_NOT_FOUND);
		}
		$l = $this->companies->logo($c);
		if ($l === null) {
			return new JSONResponse([], Http::STATUS_NOT_FOUND);
		}
		$r = new DataDisplayResponse($l['bin'], Http::STATUS_OK, ['Content-Type' => $l['mime'], 'X-Content-Type-Options' => 'nosniff']);
		$r->cacheFor(86400);
		return $r;
	}

	/** Informac o el administrador de la cuenta cambian el logo de su empresa. */
	#[NoAdminRequired]
	public function setLogo(string $id): JSONResponse {
		return $this->wrap(fn () => $this->companies->detail($this->companies->setLogo($this->guard($id), (string)($this->body()['image'] ?? ''))) + ['canEditPlan' => $this->isAdmin()]);
	}

	#[NoAdminRequired]
	public function deleteLogo(string $id): JSONResponse {
		return $this->wrap(fn () => $this->companies->detail($this->companies->removeLogo($this->guard($id))) + ['canEditPlan' => $this->isAdmin()]);
	}
}
