<?php

declare(strict_types=1);

namespace OCA\InformacNube\Service;

use OCA\GroupFolders\ACL\Rule;
use OCA\GroupFolders\ACL\RuleManager;
use OCA\GroupFolders\ACL\UserMapping\UserMapping;
use OCA\GroupFolders\Folder\FolderDefinitionWithPermissions;
use OCA\GroupFolders\Folder\FolderManager;
use OCA\GroupFolders\Mount\MountProvider;
use OCA\GroupFolders\Trash\GroupTrashItem;
use OCA\GroupFolders\Trash\TrashBackend;
use OCP\Constants;
use OCP\HintException;
use OCP\IAppConfig;
use OCP\IGroupManager;
use OCP\IUser;
use OCP\IUserManager;
use OCP\Server;
use Psr\Log\LoggerInterface;

/**
 * Empresas de Informac Nube.
 *
 * Cada empresa = 1 grupo de Nextcloud + 1 carpeta de equipo (Team folder) con la cuota del plan.
 * Las áreas son subcarpetas con permisos por persona (ACL): sin acceso / ver / editar.
 */
class CompanyService {
	public const APP = 'informacnube';
	public const LEVELS = ['none' => 0, 'read' => 1, 'edit' => 31];

	public function __construct(
		private IAppConfig $config,
		private IGroupManager $groups,
		private IUserManager $users,
		private LoggerInterface $logger,
	) {
	}

	private function folders(): FolderManager {
		return Server::get(FolderManager::class);
	}

	private function rules(): RuleManager {
		return Server::get(RuleManager::class);
	}

	// ---------- almacenamiento de la lista de empresas ----------

	public function all(): array {
		$data = json_decode($this->config->getValueString(self::APP, 'companies', '[]'), true);
		return is_array($data) ? $data : [];
	}

	private function saveAll(array $list): void {
		$this->config->setValueString(self::APP, 'companies', json_encode(array_values($list), JSON_UNESCAPED_UNICODE));
	}

	public function get(string $id): ?array {
		foreach ($this->all() as $c) {
			if ($c['id'] === $id) {
				return $c;
			}
		}
		return null;
	}

	private function put(array $company): void {
		$list = $this->all();
		$found = false;
		foreach ($list as $i => $c) {
			if ($c['id'] === $company['id']) {
				$list[$i] = $company;
				$found = true;
			}
		}
		if (!$found) {
			$list[] = $company;
		}
		$this->saveAll($list);
	}

	public function companyForUser(string $uid): ?array {
		foreach ($this->all() as $c) {
			if ($this->groups->isInGroup($uid, $c['groupId'])) {
				return $c;
			}
		}
		return null;
	}

	public function isManager(array $company, string $uid): bool {
		return in_array($uid, $company['managers'] ?? [], true)
			&& $this->groups->isInGroup($uid, (string)$company['groupId']);
	}

	private function flag($v): bool {
		return filter_var($v, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? false;
	}

	/** Cuenta administradores de la cuenta activos, sin contar a $exceptUid. */
	private function activeManagers(array $company, string $exceptUid = ''): int {
		$n = 0;
		foreach ($company['managers'] ?? [] as $m) {
			if ($m === $exceptUid) {
				continue;
			}
			$u = $this->users->get((string)$m);
			if ($u !== null && $u->isEnabled() && $this->groups->isInGroup((string)$m, (string)$company['groupId'])) {
				$n++;
			}
		}
		return $n;
	}

	private function slug(string $s): string {
		$t = @iconv('UTF-8', 'ASCII//TRANSLIT', $s);
		$s = strtolower((string)preg_replace('/[^a-zA-Z0-9]+/', '-', $t !== false ? $t : $s));
		return trim($s, '-');
	}

	// ---------- logo de la empresa ----------

	private const LOGO_MAX = 400000;
	private const LOGO_TYPES = [IMAGETYPE_PNG => 'image/png', IMAGETYPE_JPEG => 'image/jpeg', IMAGETYPE_WEBP => 'image/webp'];

	/** Guarda el logo (PNG, JPG o WEBP; nunca SVG). Llega como data URL ya achicado por el navegador. */
	public function setLogo(array $company, string $dataUrl): array {
		if (!preg_match('#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=\s]+)$#', $dataUrl, $m)) {
			throw new \InvalidArgumentException('El logo debe ser una imagen PNG, JPG o WEBP.');
		}
		$bin = base64_decode(preg_replace('/\s+/', '', $m[2]), true);
		if ($bin === false || strlen($bin) === 0) {
			throw new \InvalidArgumentException('No se pudo leer la imagen.');
		}
		if (strlen($bin) > self::LOGO_MAX) {
			throw new \InvalidArgumentException('El logo es muy pesado (máximo 400 KB).');
		}
		$info = @getimagesizefromstring($bin);
		if ($info === false || !isset(self::LOGO_TYPES[$info[2]])) {
			throw new \InvalidArgumentException('El archivo no es una imagen PNG, JPG o WEBP válida.');
		}
		$this->config->setValueString(self::APP, 'logo_' . $company['id'], json_encode(['mime' => self::LOGO_TYPES[$info[2]], 'data' => base64_encode($bin)]));
		$company = $this->get($company['id']);
		$company['logoV'] = time();
		$this->put($company);
		return $company;
	}

	public function removeLogo(array $company): array {
		$this->config->deleteKey(self::APP, 'logo_' . $company['id']);
		$company = $this->get($company['id']);
		unset($company['logoV']);
		$this->put($company);
		return $company;
	}

	/** @return array{mime:string,bin:string}|null */
	public function logo(array $company): ?array {
		$raw = json_decode($this->config->getValueString(self::APP, 'logo_' . $company['id'], ''), true);
		if (!is_array($raw) || !isset($raw['mime'], $raw['data']) || !in_array($raw['mime'], self::LOGO_TYPES, true)) {
			return null;
		}
		$bin = base64_decode((string)$raw['data'], true);
		return $bin === false ? null : ['mime' => $raw['mime'], 'bin' => $bin];
	}

	public function isMember(array $company, string $uid): bool {
		return $uid !== '' && $this->groups->isInGroup($uid, (string)$company['groupId']);
	}

	// ---------- empresas ----------

	public function createCompany(array $in): array {
		$name = trim((string)($in['name'] ?? ''));
		if ($name === '') {
			throw new \InvalidArgumentException('Falta el nombre de la empresa.');
		}
		$id = $this->slug($name);
		if ($id === '' || $this->get($id) !== null) {
			throw new \InvalidArgumentException('Ya existe una empresa con ese nombre.');
		}
		$initials = strtoupper(mb_substr(trim((string)($in['initials'] ?? '')), 0, 3));
		if ($initials === '') {
			$words = preg_split('/\s+/', $name) ?: [$name];
			foreach (array_slice($words, 0, 2) as $w) {
				$initials .= mb_strtoupper(mb_substr($w, 0, 1));
			}
		}
		$areas = $in['areas'] ?? [];
		if (!is_array($areas)) {
			$areas = explode(',', (string)$areas);
		}
		$areas = array_values(array_unique(array_filter(array_map(fn ($a) => trim((string)$a), $areas), fn ($a) => $a !== '')));
		if (count($areas) === 0) {
			$areas = ['Administración', 'Proyectos', 'Plantillas'];
		}
		$managerName = trim((string)($in['managerName'] ?? ''));
		$managerEmail = trim((string)($in['managerEmail'] ?? ''));
		if ($managerName === '' || $managerEmail === '') {
			throw new \InvalidArgumentException('Faltan el nombre y el correo del administrador de la cuenta.');
		}
		$this->validEmail($managerEmail);

		$fm = $this->folders();
		if ($fm->mountPointExists($name)) {
			throw new \InvalidArgumentException('Ya existe una carpeta de empresa con ese nombre.');
		}

		$gid = 'emp-' . $id;
		$group = $this->groups->get($gid) ?? $this->groups->createGroup($gid);
		if ($group === null) {
			throw new \RuntimeException('No se pudo crear el grupo de la empresa.');
		}
		$group->setDisplayName($name);

		$quotaGB = max(1, (float)($in['quotaGB'] ?? 500));
		$folderId = $fm->createFolder($name, [], true);
		$fm->addApplicableGroup($folderId, $gid);
		$fm->setFolderQuota($folderId, (int)round($quotaGB * 1024 * 1024 * 1024));
		$ids = $this->makeDirs($folderId, $areas);

		$company = [
			'id' => $id,
			'name' => $name,
			'initials' => $initials,
			'plan' => trim((string)($in['plan'] ?? 'Pyme')) ?: 'Pyme',
			'maxUsers' => max(1, (int)($in['maxUsers'] ?? 3)),
			'quotaGB' => $quotaGB,
			'groupId' => $gid,
			'folderId' => $folderId,
			'rootId' => $ids[''],
			'areas' => [],
			'managers' => [],
			'perms' => [],
			'created' => time(),
		];
		foreach ($areas as $a) {
			$company['areas'][] = ['name' => $a, 'fileId' => $ids[$a]];
		}

		// Reglas base: la empresa ve la raíz (solo lectura) y no entra a ningún área salvo permiso personal.
		$rm = $this->rules();
		$rm->saveRule(new Rule(new UserMapping('group', $gid), (int)$ids[''], 31, Constants::PERMISSION_READ));
		foreach ($company['areas'] as $a) {
			$rm->saveRule(new Rule(new UserMapping('group', $gid), (int)$a['fileId'], 31, 0));
		}
		$company['perms'] = [];
		$this->put($company);

		[$user, $warning] = $this->createUser($company, $managerName, $managerEmail, (string)($in['managerPassword'] ?? ''), $this->flag($in['sendInvite'] ?? true));
		$company = $this->get($id);
		$company['managers'][] = $user->getUID();
		$company['perms'][$user->getUID()] = array_fill_keys(array_column($company['areas'], 'name'), 'edit');
		$this->put($company);
		$this->applyRules($company, $user->getUID());

		return ['company' => $this->get($id), 'warning' => $warning];
	}

	public function updateCompany(array $company, array $in): array {
		if (isset($in['plan']) && trim((string)$in['plan']) !== '') {
			$company['plan'] = trim((string)$in['plan']);
		}
		if (isset($in['maxUsers'])) {
			$company['maxUsers'] = max(1, (int)$in['maxUsers']);
		}
		if (isset($in['quotaGB'])) {
			$company['quotaGB'] = max(1, (float)$in['quotaGB']);
			$this->folders()->setFolderQuota((int)$company['folderId'], (int)round($company['quotaGB'] * 1024 * 1024 * 1024));
		}
		$this->put($company);
		return $company;
	}

	/**
	 * Crea subcarpetas dentro de la carpeta de la empresa y devuelve sus ids ('' = raíz).
	 */
	private function makeDirs(int $folderId, array $names): array {
		$fm = $this->folders();
		$fm->setFolderACL($folderId, false);
		try {
			$folder = $fm->getFolder($folderId);
			$mount = Server::get(MountProvider::class)->getMount(
				FolderDefinitionWithPermissions::fromFolder($folder, $folder->rootCacheEntry, Constants::PERMISSION_ALL),
				'/dummy/files/' . $folder->mountPoint,
			);
			$storage = $mount->getStorage();
			if ($storage === null) {
				throw new \RuntimeException('No se pudo abrir la carpeta de la empresa.');
			}
			$ids = [];
			foreach ($names as $n) {
				if (!$storage->file_exists($n)) {
					$storage->mkdir($n);
				}
				$id = $storage->getCache()->getId($n);
				if ($id < 0) {
					$storage->getScanner()->scan($n);
					$id = $storage->getCache()->getId($n);
				}
				if ($id < 0) {
					throw new \RuntimeException('No se pudo crear la carpeta ' . $n);
				}
				$ids[$n] = $id;
			}
			$ids[''] = $storage->getCache()->getId('');
			return $ids;
		} finally {
			$fm->setFolderACL($folderId, true);
		}
	}

	public function addArea(array $company, string $name): array {
		$name = trim($name);
		if ($name === '' || !mb_check_encoding($name, 'UTF-8') || mb_strlen($name) > 60 || str_starts_with($name, '.')
			|| preg_match('#[/\\\\:*?"<>|\x00-\x1F]#u', $name) !== 0) {
			throw new \InvalidArgumentException('Nombre de área no válido. Usa letras, números y espacios.');
		}
		foreach ($company['areas'] as $a) {
			if (mb_strtolower($a['name']) === mb_strtolower($name)) {
				throw new \InvalidArgumentException('Esa área ya existe.');
			}
		}
		$ids = $this->makeDirs((int)$company['folderId'], [$name]);
		$company['areas'][] = ['name' => $name, 'fileId' => $ids[$name]];
		$this->rules()->saveRule(new Rule(new UserMapping('group', $company['groupId']), (int)$ids[$name], 31, 0));
		$this->put($company);
		foreach (array_keys($company['perms'] ?? []) as $uid) {
			$this->applyRules($company, (string)$uid);
		}
		return $company;
	}

	// ---------- personas ----------

	private function validEmail(string $email): void {
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			throw new \InvalidArgumentException('El correo "' . $email . '" no es válido.');
		}
	}

	public function countActive(array $company): int {
		$g = $this->groups->get($company['groupId']);
		if ($g === null) {
			return 0;
		}
		$n = 0;
		foreach ($g->getUsers() as $u) {
			if ($u->isEnabled()) {
				$n++;
			}
		}
		return $n;
	}

	/** @return array{0: IUser, 1: ?string} */
	private function createUser(array $company, string $name, string $email, string $password, bool $sendInvite = true): array {
		$email = strtolower(trim($email));
		$this->validEmail($email);
		if ($this->users->userExists($email)) {
			throw new \InvalidArgumentException('Ese correo no se puede usar para una cuenta nueva. Si la persona ya tiene cuenta, contacta a Informac.');
		}
		if ($this->countActive($company) >= (int)$company['maxUsers']) {
			throw new \InvalidArgumentException('El plan ' . $company['plan'] . ' permite ' . $company['maxUsers'] . ' usuarios y ya están todos ocupados. Pide a Informac ampliar el plan.');
		}
		$invite = trim($password) === '';
		if ($invite) {
			$password = bin2hex(random_bytes(16)) . 'Aa1!';
		}
		try {
			$user = $this->users->createUser($email, $password);
		} catch (HintException $e) {
			throw new \InvalidArgumentException($e->getHint() ?: $e->getMessage());
		}
		if (!$user instanceof IUser) {
			throw new \RuntimeException('No se pudo crear el usuario.');
		}
		$user->setDisplayName(trim($name) !== '' ? trim($name) : $email);
		$user->setSystemEMailAddress($email);
		$this->groups->get($company['groupId'])?->addUser($user);

		$warning = null;
		if ($invite && $sendInvite) {
			try {
				$helper = Server::get(\OCA\Settings\Mailer\NewUserMailHelper::class);
				$helper->sendMail($user, $helper->generateTemplate($user, true));
			} catch (\Throwable $e) {
				$this->logger->warning('informacnube: invitación no enviada: ' . $e->getMessage());
				$warning = 'Usuario creado, pero el correo de invitación no se pudo enviar. Asígnale una contraseña con "Contraseña".';
			}
		}
		return [$user, $warning];
	}

	private function normalizeAreas(array $company, $areas): array {
		$out = [];
		foreach ($company['areas'] as $a) {
			$lvl = is_array($areas) ? ($areas[$a['name']] ?? 'none') : 'none';
			$out[$a['name']] = isset(self::LEVELS[$lvl]) ? $lvl : 'none';
		}
		return $out;
	}

	public function applyRules(array $company, string $uid): void {
		$rm = $this->rules();
		$isManager = $this->isManager($company, $uid);
		$perms = $company['perms'][$uid] ?? [];
		$rm->saveRule(new Rule(new UserMapping('user', $uid), (int)$company['rootId'], 31, $isManager ? 31 : Constants::PERMISSION_READ));
		foreach ($company['areas'] as $a) {
			$lvl = $isManager ? 'edit' : ($perms[$a['name']] ?? 'none');
			$rm->saveRule(new Rule(new UserMapping('user', $uid), (int)$a['fileId'], 31, self::LEVELS[$lvl] ?? 0));
		}
	}

	public function addMember(array $company, array $in): array {
		[$user, $warning] = $this->createUser($company, (string)($in['name'] ?? ''), (string)($in['email'] ?? ''), (string)($in['password'] ?? ''), $this->flag($in['sendInvite'] ?? true));
		$uid = $user->getUID();
		$company = $this->get($company['id']);
		$company['perms'][$uid] = $this->normalizeAreas($company, $in['areas'] ?? []);
		$this->put($company);
		$this->applyRules($company, $uid);
		return ['uid' => $uid, 'warning' => $warning];
	}

	public function updateMember(array $company, string $uid, array $in, string $actor, bool $actorIsAdmin): array {
		if (!$this->groups->isInGroup($uid, $company['groupId'])) {
			throw new \InvalidArgumentException('Esa persona no pertenece a esta empresa.');
		}
		$user = $this->users->get($uid);
		if ($user === null) {
			throw new \InvalidArgumentException('Usuario no encontrado.');
		}
		if (!$actorIsAdmin) {
			// Un administrador de la cuenta solo gestiona personas de SU empresa creadas por el panel.
			$foreign = $this->groups->isAdmin($uid)
				|| (!isset($company['perms'][$uid]) && !in_array($uid, $company['managers'] ?? [], true));
			foreach ($this->all() as $other) {
				if ($other['id'] !== $company['id'] && $this->groups->isInGroup($uid, (string)$other['groupId'])) {
					$foreign = true;
				}
			}
			if ($foreign) {
				throw new \DomainException('Esa persona solo puede ser administrada por Informac.');
			}
		}
		if (array_key_exists('manager', $in)) {
			if (!$actorIsAdmin) {
				throw new \InvalidArgumentException('Solo Informac puede cambiar al administrador de la cuenta.');
			}
			$managers = array_values(array_diff($company['managers'] ?? [], [$uid]));
			if (!$this->flag($in['manager']) && $this->isManager($company, $uid) && $this->activeManagers($company, $uid) === 0) {
				throw new \InvalidArgumentException('La empresa debe tener al menos un administrador de la cuenta activo.');
			}
			if ($this->flag($in['manager'])) {
				$managers[] = $uid;
			}
			$company['managers'] = $managers;
		}
		if (array_key_exists('areas', $in)) {
			$company['perms'][$uid] = $this->normalizeAreas($company, $in['areas']);
		}
		if (array_key_exists('enabled', $in)) {
			$enable = $this->flag($in['enabled']);
			if (!$enable && $uid === $actor) {
				throw new \InvalidArgumentException('No puedes darte de baja a ti mismo.');
			}
			if (!$enable && $this->isManager($company, $uid) && $this->activeManagers($company, $uid) === 0) {
				throw new \InvalidArgumentException('No se puede dar de baja al único administrador de la cuenta activo.');
			}
			if ($enable && !$user->isEnabled() && $this->countActive($company) >= (int)$company['maxUsers']) {
				throw new \InvalidArgumentException('El plan ya tiene todos sus usuarios ocupados.');
			}
			$user->setEnabled($enable);
		}
		if (isset($in['password']) && trim((string)$in['password']) !== '') {
			try {
				if (!$user->setPassword((string)$in['password'])) {
					throw new \InvalidArgumentException('No se pudo cambiar la contraseña.');
				}
			} catch (HintException $e) {
				throw new \InvalidArgumentException($e->getHint() ?: $e->getMessage());
			}
		}
		if (isset($in['name']) && trim((string)$in['name']) !== '') {
			$user->setDisplayName(trim((string)$in['name']));
		}
		$this->put($company);
		$this->applyRules($company, $uid);
		return $company;
	}

	// ---------- papelera de la empresa ----------

	/** Usuario con acceso total a la carpeta de la empresa (un administrador de la cuenta activo). */
	private function fullAccessUser(array $company): IUser {
		foreach ($company['managers'] ?? [] as $uid) {
			$u = $this->users->get($uid);
			if ($u !== null && $u->isEnabled()) {
				return $u;
			}
		}
		throw new \InvalidArgumentException('La empresa no tiene un administrador de la cuenta activo.');
	}

	private function trashBackend(): TrashBackend {
		return Server::get(TrashBackend::class);
	}

	public function trashList(array $company): array {
		$user = $this->fullAccessUser($company);
		$out = [];
		foreach ($this->trashBackend()->listTrashRoot($user) as $item) {
			if (!$item instanceof GroupTrashItem || (int)$item->folder->id !== (int)$company['folderId']) {
				continue;
			}
			$by = $item->getDeletedBy();
			$loc = dirname((string)$item->getOriginalLocation());
			$out[] = [
				'name' => $item->getName(),
				'title' => $item->getTitle(),
				'location' => ($loc === '.' || $loc === '') ? $company['name'] : $company['name'] . ' › ' . str_replace('/', ' › ', $loc),
				'deletedAt' => $item->getDeletedTime(),
				'deletedBy' => $by?->getDisplayName(),
				'size' => $item->getSize(),
				'isFolder' => $item->getType() === \OCP\Files\FileInfo::TYPE_FOLDER,
			];
		}
		usort($out, fn ($a, $b) => $b['deletedAt'] <=> $a['deletedAt']);
		return $out;
	}

	public function trashRestore(array $company, string $name): void {
		if ($name === '') {
			throw new \InvalidArgumentException('Falta el archivo a restaurar.');
		}
		$user = $this->fullAccessUser($company);
		$tb = $this->trashBackend();
		$item = $tb->getTrashRootItem($user, $name);
		if (!$item instanceof GroupTrashItem || (int)$item->folder->id !== (int)$company['folderId']) {
			throw new \InvalidArgumentException('Ese archivo no pertenece a esta empresa.');
		}
		$tb->restoreItem($item);
	}

	// ---------- vista ----------

	public function detail(array $company): array {
		$members = [];
		$g = $this->groups->get($company['groupId']);
		$names = [];
		foreach ($company['areas'] as $a) {
			$names[] = $a['name'];
		}
		if ($g !== null) {
			foreach ($g->getUsers() as $u) {
				$uid = $u->getUID();
				$isManager = $this->isManager($company, $uid);
				$areas = $isManager ? array_fill_keys($names, 'edit') : $this->normalizeAreas($company, $company['perms'][$uid] ?? []);
				$members[] = [
					'uid' => $uid,
					'name' => $u->getDisplayName(),
					'email' => $u->getSystemEMailAddress() ?? $uid,
					'enabled' => $u->isEnabled(),
					'manager' => $isManager,
					'lastLogin' => $u->getLastLogin(),
					'areas' => $areas,
				];
			}
		}
		usort($members, fn ($a, $b) => [$b['manager'], $b['enabled'], $a['name']] <=> [$a['manager'], $a['enabled'], $b['name']]);

		$used = 0;
		$quota = (int)round(((float)$company['quotaGB']) * 1024 * 1024 * 1024);
		try {
			$f = $this->folders()->getFolder((int)$company['folderId']);
			$used = (int)($f->rootCacheEntry?->getSize() ?? 0);
			if ($f->quota > 0) {
				$quota = $f->quota;
			}
		} catch (\Throwable $e) {
			$this->logger->warning('informacnube: ' . $e->getMessage());
		}

		return [
			'id' => $company['id'],
			'name' => $company['name'],
			'initials' => $company['initials'],
			'logo' => (int)($company['logoV'] ?? 0),
			'plan' => $company['plan'],
			'maxUsers' => (int)$company['maxUsers'],
			'quotaGB' => (float)$company['quotaGB'],
			'activeUsers' => count(array_filter($members, fn ($m) => $m['enabled'])),
			'usedBytes' => max(0, $used),
			'quotaBytes' => $quota,
			'areas' => $names,
			'members' => $members,
		];
	}
}
