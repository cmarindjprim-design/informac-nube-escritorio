/* Informac Nube — muestra la empresa del usuario en la barra superior y el enlace de soporte. */
(function () {
	'use strict'
	function url(p) { return (window.OC && OC.generateUrl) ? OC.generateUrl(p) : '/index.php' + p }
	function run() {
		const header = document.querySelector('#header')
		if (!header || header.querySelector('.inp-co, .inp-help')) return
		const start = header.querySelector('.header-start, .header-left')
		const end = header.querySelector('.header-end, .header-right')
		if (end) {
			const help = document.createElement('a')
			help.className = 'inp-help'
			help.href = 'https://informac.cl'
			help.target = '_blank'
			help.rel = 'noopener'
			help.textContent = 'Ayuda · Soporte Informac'
			end.insertBefore(help, end.firstChild)
		}
		fetch(url('/apps/informacnube/api/me'), { headers: { Accept: 'application/json', requesttoken: (window.OC && OC.requestToken) || '' }, credentials: 'same-origin' })
			.then((r) => r.ok ? r.json() : null)
			.then((me) => {
				if (!me || !me.company || !start || header.querySelector('.inp-co')) return
				const co = document.createElement('div')
				co.className = 'inp-co'
				const b = document.createElement('span')
				b.className = 'inp-co__badge'
				if (me.company.logo) {
					// Logo de la empresa (si falla, vuelve a la sigla)
					b.classList.add('inp-co__badge--logo')
					const img = document.createElement('img')
					img.alt = me.company.name
					img.src = url('/apps/informacnube/api/companies/' + encodeURIComponent(me.company.id) + '/logo') + '?v=' + me.company.logo
					img.onerror = () => { b.classList.remove('inp-co__badge--logo'); b.textContent = me.company.initials }
					b.appendChild(img)
				} else {
					b.textContent = me.company.initials
				}
				const n = document.createElement('span')
				n.className = 'inp-co__name'
				n.textContent = me.company.name
				co.append(b, n)
				const logo = start.querySelector('.logo, #nextcloud, .header-start__logo')
				if (logo && logo.parentNode === start) logo.after(co)
				else start.insertBefore(co, start.children[1] || null)
			})
			.catch(() => {})
	}
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run)
	else run()
})()
