/* Panel Informac — vista de Informac (empresas) y del administrador de la cuenta (su equipo). Sin dependencias. */
(function () {
	'use strict'

	const LEVEL_LABEL = { none: 'Sin acceso', read: 'Solo ver', edit: 'Editar' }
	const PLANS = [
		{ name: 'Pyme', maxUsers: 3, quotaGB: 500 },
		{ name: 'Pyme Plus', maxUsers: 10, quotaGB: 1024 },
		{ name: 'Empresa', maxUsers: 25, quotaGB: 2048 },
	]

	const root = () => document.getElementById('informac-panel')
	const token = () => (window.OC && OC.requestToken) || document.head.dataset.requesttoken || ''
	const url = (p) => (window.OC && OC.generateUrl ? OC.generateUrl('/apps/informacnube/api' + p) : '/index.php/apps/informacnube/api' + p)

	async function api(path, method = 'GET', body) {
		const res = await fetch(url(path), {
			method,
			headers: { requesttoken: token(), 'Content-Type': 'application/json', Accept: 'application/json' },
			body: body ? JSON.stringify(body) : undefined,
			credentials: 'same-origin',
		})
		let data = null
		try { data = await res.json() } catch (e) { /* vacío */ }
		if (!res.ok) throw new Error((data && data.error) || ('Error ' + res.status))
		return data
	}

	function h(tag, attrs, ...children) {
		const el = document.createElement(tag)
		for (const [k, v] of Object.entries(attrs || {})) {
			if (v === null || v === undefined || v === false) continue
			if (k === 'class') el.className = v
			else if (k === 'style') el.setAttribute('style', v)
			else if (k.startsWith('on')) el.addEventListener(k.slice(2), v)
			else if (k === 'value') el.value = v
			else el.setAttribute(k, v === true ? '' : v)
		}
		for (const c of children.flat()) {
			if (c === null || c === undefined || c === false) continue
			el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)))
		}
		return el
	}

	const fmtBytes = (b) => {
		const gb = b / 1073741824
		if (gb >= 1) return gb.toLocaleString('es-CL', { maximumFractionDigits: 1 }) + ' GB'
		const mb = b / 1048576
		return mb.toLocaleString('es-CL', { maximumFractionDigits: mb < 10 ? 1 : 0 }) + ' MB'
	}
	const initials = (name) => (name || '?').split(/[\s@.]+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('')
	const logoUrl = (c) => url('/companies/' + encodeURIComponent(c.id) + '/logo') + '?v=' + c.logo
	// Logo de la empresa si lo tiene; si no, la sigla.
	const badge = (c, extra) => c.logo
		? h('span', { class: 'inp-badge inp-badge--logo' + (extra ? ' ' + extra : '') }, h('img', { src: logoUrl(c), alt: c.name }))
		: h('span', { class: 'inp-badge' + (extra ? ' ' + extra : '') }, c.initials)
	const pct = (a, b) => Math.max(0, Math.min(100, b > 0 ? Math.round((a / b) * 100) : 0))
	const bar = (p) => h('div', { class: 'inp-bar' }, h('div', { class: 'inp-bar__fill' + (p >= 90 ? ' inp-bar__fill--warn' : ''), style: 'width:' + p + '%' }))

	let ME = null
	let notice = null

	function flash(msg, kind) {
		notice = msg ? { msg, kind: kind || 'ok' } : null
	}

	function noticeEl() {
		if (!notice) return null
		const n = notice
		notice = null
		return h('div', { class: 'inp-notice inp-notice--' + n.kind }, n.msg)
	}

	// ---------- diálogo genérico ----------
	function dialog(title, fields, submitLabel, onSubmit, intro) {
		const err = h('div', { class: 'inp-error', role: 'alert' })
		const inputs = {}
		const form = h('form', { class: 'inp-form' },
			intro ? h('p', { class: 'inp-muted' }, intro) : null,
			fields.map((f) => {
				if (f.type === 'section') return h('div', { class: 'inp-form__section' }, f.label)
				let input
				if (f.type === 'select') {
					input = h('select', { name: f.name }, f.options.map((o) => h('option', { value: o.value, selected: o.value === f.value }, o.label)))
				} else {
					input = h('input', { name: f.name, type: f.type || 'text', value: f.value ?? '', placeholder: f.placeholder || '', required: f.required, autocomplete: f.autocomplete || 'off', min: f.min, step: f.step })
				}
				if (f.onchange) input.addEventListener('change', () => f.onchange(input.value, inputs))
				inputs[f.name] = input
				return h('label', { class: 'inp-field' + (f.inline ? ' inp-field--inline' : '') }, h('span', null, f.label), input, f.help ? h('small', null, f.help) : null)
			}),
			err,
			h('div', { class: 'inp-form__actions' },
				h('button', { type: 'button', class: 'inp-btn', onclick: () => close() }, 'Cancelar'),
				h('button', { type: 'submit', class: 'inp-btn inp-btn--primary' }, submitLabel),
			),
		)
		const overlay = h('div', { class: 'inp-overlay', onclick: (e) => { if (e.target === overlay) close() } },
			h('div', { class: 'inp-dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
				h('h2', null, title), form))
		function close() { overlay.remove() }
		form.addEventListener('submit', async (e) => {
			e.preventDefault()
			err.textContent = ''
			const btn = form.querySelector('button[type=submit]')
			btn.disabled = true
			btn.textContent = 'Guardando…'
			const values = {}
			for (const [k, el] of Object.entries(inputs)) values[k] = el.value
			try {
				await onSubmit(values)
				close()
			} catch (ex) {
				err.textContent = ex.message
				btn.disabled = false
				btn.textContent = submitLabel
			}
		})
		document.body.appendChild(overlay)
		const first = form.querySelector('input,select')
		if (first) first.focus()
	}

	const areaFields = (areas, current) => areas.map((a) => ({
		name: 'area:' + a, label: a, type: 'select', inline: true, value: (current && current[a]) || 'none',
		options: [{ value: 'none', label: 'Sin acceso' }, { value: 'read', label: 'Solo ver' }, { value: 'edit', label: 'Editar' }],
	}))
	const pickAreas = (values) => {
		const out = {}
		for (const [k, v] of Object.entries(values)) if (k.startsWith('area:')) out[k.slice(5)] = v
		return out
	}

	// ---------- vista de una empresa (administrador de la cuenta / Informac) ----------
	async function showCompany(id) {
		const d = await api('/companies/' + encodeURIComponent(id))
		const R = root()
		R.innerHTML = ''
		const managers = d.members.filter((m) => m.manager).map((m) => m.name)
		const full = d.activeUsers >= d.maxUsers
		const reload = async (msg, kind) => { flash(msg, kind); await showCompany(id) }

		const header = h('div', { class: 'inp-head' },
			badge(d),
			h('div', { class: 'inp-head__title' },
				ME.isAdmin ? h('a', { href: '#', class: 'inp-back', onclick: (e) => { e.preventDefault(); showCompanies() } }, '← Todas las empresas') : null,
				h('span', { class: 'inp-head__name' }, d.name),
				h('span', { class: 'inp-muted' }, 'Equipo · ' + (managers.length > 1 ? 'Administradores de la cuenta: ' : 'Administrador de la cuenta: ') + (managers.join(', ') || '—')),
				h('button', { class: 'inp-link inp-link--left', onclick: () => editLogo(d, reload) }, d.logo ? 'Cambiar logo' : 'Poner logo de la empresa'),
			),
			h('div', { class: 'inp-head__plan' },
				h('span', null, 'Plan ' + d.plan + ' · ' + d.activeUsers + ' de ' + d.maxUsers + ' usuarios'),
				bar(pct(d.activeUsers, d.maxUsers)),
				h('span', null, fmtBytes(d.usedBytes) + ' de ' + fmtBytes(d.quotaBytes)),
				bar(pct(d.usedBytes, d.quotaBytes)),
				d.canEditPlan ? h('button', { class: 'inp-link', onclick: () => editPlan(d, reload) }, 'Cambiar plan') : null,
			),
		)

		const rows = d.members.map((m) => {
			const edit = Object.entries(m.areas).filter(([, l]) => l === 'edit').map(([a]) => a)
			const read = Object.entries(m.areas).filter(([, l]) => l === 'read').map(([a]) => a)
			const areasTxt = m.manager ? 'Todas' : [edit.join(' · '), read.length ? '(ve: ' + read.join(' · ') + ')' : ''].filter(Boolean).join(' ') || 'Sin áreas'
			return h('div', { class: 'inp-row' + (m.enabled ? '' : ' inp-row--off') },
				h('div', { class: 'inp-cell-name' }, h('span', { class: 'inp-avatar' }, initials(m.name)), h('span', { class: 'inp-name' }, m.name, m.manager ? h('small', { class: 'inp-role' }, 'Administrador de la cuenta') : null)),
				h('div', { class: 'inp-muted inp-ellipsis', title: m.email }, m.email),
				h('div', { class: 'inp-ellipsis', title: areasTxt }, areasTxt),
				h('div', { class: m.enabled ? 'inp-ok' : 'inp-muted' }, m.enabled ? 'Activo' : 'Dado de baja'),
				h('div', { class: 'inp-actions' },
					!m.manager ? h('button', { class: 'inp-link', onclick: () => editAreas(d, m, reload) }, 'Permisos') : null,
					h('button', { class: 'inp-link', onclick: () => setPassword(d, m, reload) }, 'Contraseña'),
					m.uid !== ME.uid ? h('button', {
						class: 'inp-link' + (m.enabled ? ' inp-link--danger' : ''),
						onclick: async () => {
							if (m.enabled && !confirm('¿Dar de baja a ' + m.name + '? No podrá entrar, pero sus archivos se mantienen y se libera su cupo.')) return
							try { await api('/companies/' + d.id + '/members/' + encodeURIComponent(m.uid), 'PUT', { enabled: !m.enabled }); await reload(m.enabled ? m.name + ' fue dado de baja.' : m.name + ' fue reactivado.') } catch (e) { await reload(e.message, 'error') }
						},
					}, m.enabled ? 'Dar de baja' : 'Reactivar') : null,
					ME.isAdmin ? h('button', {
						class: 'inp-link',
						onclick: async () => { try { await api('/companies/' + d.id + '/members/' + encodeURIComponent(m.uid), 'PUT', { manager: !m.manager }); await reload('Administradores actualizados.') } catch (e) { await reload(e.message, 'error') } },
					}, m.manager ? 'Quitar administrador' : 'Hacer administrador') : null,
				),
			)
		})

		const permCards = d.areas.map((a) => {
			const active = d.members.filter((m) => m.enabled)
			const ed = active.filter((m) => m.areas[a] === 'edit').map((m) => m.name.split(' ')[0])
			const rd = active.filter((m) => m.areas[a] === 'read').map((m) => m.name.split(' ')[0])
			return h('div', { class: 'inp-card' },
				h('strong', null, a),
				h('span', { class: 'inp-ok' }, 'Editan: ' + (ed.join(', ') || 'nadie')),
				h('span', { class: 'inp-muted' }, 'Solo ven: ' + (rd.join(', ') || 'nadie')))
		})

		const trashBox = h('div', { class: 'inp-trash' }, h('p', { class: 'inp-muted inp-small' }, 'Cargando papelera…'))
		loadTrash(d, trashBox, reload)

		R.append(...[
			header,
			noticeEl(),
			h('div', { class: 'inp-body' },
				h('section', { class: 'inp-main' },
					h('div', { class: 'inp-titlebar' },
						h('h1', null, 'Integrantes'),
						h('button', { class: 'inp-btn inp-btn--primary', disabled: full, title: full ? 'El plan no tiene cupos libres' : null, onclick: () => addMember(d, reload) }, '+ Agregar integrante'),
					),
					full ? h('p', { class: 'inp-warn' }, 'Usaste los ' + d.maxUsers + ' usuarios de tu plan. Para agregar a alguien, da de baja a otra persona o pide a Informac ampliar el plan.') : null,
					h('div', { class: 'inp-table' },
						h('div', { class: 'inp-row inp-row--head' }, h('div', null, 'NOMBRE'), h('div', null, 'CORREO'), h('div', null, 'ÁREAS'), h('div', null, 'ESTADO'), h('div', null, '')),
						rows),
					trashBox,
				),
				h('aside', { class: 'inp-side' },
					h('div', { class: 'inp-titlebar' }, h('h2', null, 'Permisos por área'), h('button', { class: 'inp-link', onclick: () => addArea(d, reload) }, '+ Nueva área')),
					permCards,
					h('p', { class: 'inp-muted inp-small' }, 'Aquí creas y das de baja a tu gente sin llamar a Informac. Cada persona solo ve las áreas que le asignes, y nadie de otra empresa puede ver tus archivos.'),
				),
			),
		].filter(Boolean))
	}

	async function loadTrash(d, box, reload) {
		let items
		try { items = await api('/companies/' + d.id + '/trash') } catch (e) { box.innerHTML = ''; box.append(h('p', { class: 'inp-warn' }, 'No se pudo leer la papelera: ' + e.message)); return }
		const fmtDate = (t) => new Date(t * 1000).toLocaleString('es-CL', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
		box.innerHTML = ''
		box.append(
			h('div', { class: 'inp-titlebar' },
				h('h1', null, 'Papelera de la empresa'),
				h('span', { class: 'inp-muted inp-small' }, 'Todo lo borrado se guarda 30 días')),
			items.length === 0
				? h('div', { class: 'inp-empty inp-empty--box' }, 'No hay archivos eliminados. Si alguien borra algo por error, aparecerá aquí y podrás restaurarlo con un clic.')
				: h('div', { class: 'inp-table inp-table--trash' },
					h('div', { class: 'inp-row inp-row--head' }, h('div', null, 'ARCHIVO'), h('div', null, 'ESTABA EN'), h('div', null, 'BORRADO POR'), h('div', null, 'FECHA'), h('div', null, '')),
					items.map((it) => h('div', { class: 'inp-row' },
						h('div', { class: 'inp-cell-name' }, h('span', { class: 'inp-avatar inp-avatar--file' }, it.isFolder ? 'DIR' : ((it.title.split('.').pop() || '').slice(0, 3).toUpperCase() || 'ARC')), h('span', { class: 'inp-ellipsis', title: it.title }, it.title)),
						h('div', { class: 'inp-muted inp-ellipsis', title: it.location }, it.location || '—'),
						h('div', null, it.deletedBy || '—'),
						h('div', { class: 'inp-muted' }, fmtDate(it.deletedAt)),
						h('div', { class: 'inp-actions' }, h('button', {
							class: 'inp-btn',
							onclick: async (e) => {
								e.target.disabled = true
								e.target.textContent = 'Restaurando…'
								try { await api('/companies/' + d.id + '/trash/restore', 'POST', { name: it.name }); await reload('"' + it.title + '" fue restaurado en ' + (it.location || 'su carpeta') + '.') } catch (ex) { await reload(ex.message, 'error') }
							},
						}, 'Restaurar')),
					))),
		)
	}

	function addMember(d, reload) {
		dialog('Agregar integrante', [
			{ name: 'name', label: 'Nombre y apellido', required: true, placeholder: 'Ej: Juan Pérez' },
			{ name: 'email', label: 'Correo', type: 'email', required: true, placeholder: 'jperez@empresa.cl', help: 'Con este correo inicia sesión.' },
			{ name: 'password', label: 'Contraseña inicial (opcional)', type: 'password', autocomplete: 'new-password', help: 'Si la dejas vacía, le llega un correo para que cree su propia contraseña.' },
			{ type: 'section', label: '¿A qué áreas entra?' },
			...areaFields(d.areas),
		], 'Agregar', async (v) => {
			const r = await api('/companies/' + d.id + '/members', 'POST', { name: v.name, email: v.email, password: v.password, areas: pickAreas(v) })
			await reload(r.warning || (v.name + ' ya puede entrar a la nube.'), r.warning ? 'warn' : 'ok')
		}, 'Quedan ' + (d.maxUsers - d.activeUsers) + ' de ' + d.maxUsers + ' usuarios en el plan ' + d.plan + '.')
	}

	function editAreas(d, m, reload) {
		dialog('Permisos de ' + m.name, areaFields(d.areas, m.areas), 'Guardar', async (v) => {
			await api('/companies/' + d.id + '/members/' + encodeURIComponent(m.uid), 'PUT', { areas: pickAreas(v) })
			await reload('Permisos de ' + m.name + ' actualizados.')
		}, 'Elige qué puede hacer en cada área.')
	}

	function setPassword(d, m, reload) {
		dialog('Nueva contraseña para ' + m.name, [
			{ name: 'password', label: 'Contraseña nueva', type: 'password', required: true, autocomplete: 'new-password', help: 'Mínimo 10 caracteres. Entrégasela a la persona por un medio seguro.' },
		], 'Cambiar', async (v) => {
			await api('/companies/' + d.id + '/members/' + encodeURIComponent(m.uid), 'PUT', { password: v.password })
			await reload('Contraseña de ' + m.name + ' cambiada.')
		})
	}

	// Logo: el navegador lo achica (máx. 480×160) y lo envía como PNG; se acepta PNG, JPG o WEBP.
	function editLogo(d, reload) {
		const err = h('div', { class: 'inp-error', role: 'alert' })
		const prev = h('div', { class: 'inp-logo-prev' }, d.logo ? h('img', { src: logoUrl(d), alt: '' }) : h('span', { class: 'inp-muted' }, 'Sin logo: se muestra la sigla ' + d.initials))
		let dataUrl = ''
		const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' })
		file.addEventListener('change', () => {
			err.textContent = ''
			const f = file.files && file.files[0]
			if (!f) return
			if (!/^image\/(png|jpeg|webp)$/.test(f.type)) { err.textContent = 'Usa una imagen PNG, JPG o WEBP.'; return }
			const img = new Image()
			img.onload = () => {
				const k = Math.min(1, 480 / img.width, 160 / img.height)
				const cv = document.createElement('canvas')
				cv.width = Math.max(1, Math.round(img.width * k)); cv.height = Math.max(1, Math.round(img.height * k))
				cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height)
				dataUrl = cv.toDataURL('image/png')
				prev.innerHTML = ''
				prev.append(h('img', { src: dataUrl, alt: '' }))
				URL.revokeObjectURL(img.src)
			}
			img.onerror = () => { err.textContent = 'No se pudo abrir la imagen.' }
			img.src = URL.createObjectURL(f)
		})
		const save = h('button', { type: 'submit', class: 'inp-btn inp-btn--primary' }, 'Guardar logo')
		const form = h('form', { class: 'inp-form' },
			h('p', { class: 'inp-muted' }, 'Se muestra en la barra superior de la nube para todas las personas de ' + d.name + ', y en este panel. Ideal: PNG con fondo transparente, horizontal.'),
			prev,
			h('label', { class: 'inp-field' }, h('span', null, 'Imagen del logo'), file),
			err,
			h('div', { class: 'inp-form__actions' },
				d.logo ? h('button', {
					type: 'button', class: 'inp-btn', style: 'color:#C4122F', onclick: async () => {
						try { await api('/companies/' + d.id + '/logo', 'DELETE'); close(); await reload('Logo quitado. Se vuelve a mostrar la sigla.') } catch (ex) { err.textContent = ex.message }
					},
				}, 'Quitar logo') : null,
				h('button', { type: 'button', class: 'inp-btn', onclick: () => close() }, 'Cancelar'),
				save,
			),
		)
		const overlay = h('div', { class: 'inp-overlay', onclick: (e) => { if (e.target === overlay) close() } },
			h('div', { class: 'inp-dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Logo de la empresa' }, h('h2', null, 'Logo de ' + d.name), form))
		function close() { overlay.remove() }
		form.addEventListener('submit', async (e) => {
			e.preventDefault()
			if (!dataUrl) { err.textContent = 'Elige primero una imagen.'; return }
			save.disabled = true; save.textContent = 'Guardando…'
			try { await api('/companies/' + d.id + '/logo', 'POST', { image: dataUrl }); close(); await reload('Logo guardado. Las personas lo verán al recargar la página.') } catch (ex) { err.textContent = ex.message; save.disabled = false; save.textContent = 'Guardar logo' }
		})
		document.body.appendChild(overlay)
	}

	function addArea(d, reload) {
		dialog('Nueva área', [{ name: 'name', label: 'Nombre del área', required: true, placeholder: 'Ej: Finanzas' }], 'Crear', async (v) => {
			await api('/companies/' + d.id + '/areas', 'POST', { name: v.name })
			await reload('Área "' + v.name + '" creada. Asigna quién entra con "Permisos".')
		}, 'Se crea una carpeta nueva en el espacio de la empresa. Al principio nadie entra, salvo los administradores de la cuenta.')
	}

	function editPlan(d, reload) {
		dialog('Plan de ' + d.name, [
			{ name: 'plan', label: 'Nombre del plan', value: d.plan, required: true },
			{ name: 'maxUsers', label: 'Usuarios incluidos', type: 'number', min: 1, value: d.maxUsers, required: true },
			{ name: 'quotaGB', label: 'Espacio (GB)', type: 'number', min: 1, step: 1, value: d.quotaGB, required: true },
		], 'Guardar', async (v) => {
			await api('/companies/' + d.id, 'PUT', { plan: v.plan, maxUsers: +v.maxUsers, quotaGB: +v.quotaGB })
			await reload('Plan actualizado.')
		})
	}

	// ---------- vista de Informac: todas las empresas ----------
	async function showCompanies() {
		const list = await api('/companies')
		const R = root()
		R.innerHTML = ''
		const tUsers = list.reduce((s, c) => s + c.activeUsers, 0)
		const tQuota = list.reduce((s, c) => s + c.quotaBytes, 0)
		const tUsed = list.reduce((s, c) => s + c.usedBytes, 0)
		R.append(...[
			h('div', { class: 'inp-head' },
				h('div', { class: 'inp-head__title' },
					h('span', { class: 'inp-head__name' }, 'Panel Informac'),
					h('span', { class: 'inp-muted' }, 'Empresas clientes de Informac Nube')),
				h('div', { class: 'inp-head__plan' },
					h('span', null, list.length + ' empresas · ' + tUsers + ' usuarios activos'),
					h('span', null, fmtBytes(tUsed) + ' usados de ' + fmtBytes(tQuota) + ' vendidos')),
			),
			noticeEl(),
			h('div', { class: 'inp-body' },
				h('section', { class: 'inp-main' },
					h('div', { class: 'inp-titlebar' },
						h('h1', null, 'Empresas'),
						h('button', { class: 'inp-btn inp-btn--primary', onclick: newCompany }, '+ Nueva empresa')),
					list.length === 0
						? h('div', { class: 'inp-empty' }, 'Todavía no hay empresas. Crea la primera con "+ Nueva empresa".')
						: h('div', { class: 'inp-table inp-table--co' },
							h('div', { class: 'inp-row inp-row--head' }, h('div', null, 'EMPRESA'), h('div', null, 'PLAN'), h('div', null, 'USUARIOS'), h('div', null, 'ESPACIO'), h('div', null, 'ADMINISTRADOR'), h('div', null, '')),
							list.map((c) => h('div', { class: 'inp-row' },
								h('div', { class: 'inp-cell-name' }, badge(c, 'inp-badge--sm'), h('span', null, c.name)),
								h('div', null, c.plan),
								h('div', null, h('span', null, c.activeUsers + ' de ' + c.maxUsers), bar(pct(c.activeUsers, c.maxUsers))),
								h('div', null, h('span', null, fmtBytes(c.usedBytes) + ' de ' + fmtBytes(c.quotaBytes)), bar(pct(c.usedBytes, c.quotaBytes))),
								h('div', { class: 'inp-ellipsis' }, c.members.filter((m) => m.manager).map((m) => m.name).join(', ') || '—'),
								h('div', null, h('button', { class: 'inp-btn', onclick: () => showCompany(c.id).catch(fail) }, 'Administrar')),
							))),
				),
				h('aside', { class: 'inp-side' },
					h('h2', null, 'Cómo funciona'),
					h('div', { class: 'inp-card' }, h('strong', null, '1. Tú creas la empresa'), h('span', { class: 'inp-muted' }, 'Con su plan: usuarios incluidos y espacio. Se crea su carpeta privada y sus áreas.')),
					h('div', { class: 'inp-card' }, h('strong', null, '2. El administrador de la cuenta gestiona'), h('span', { class: 'inp-muted' }, 'Entra con su correo, ve "Mi equipo" y agrega a su gente hasta el tope del plan.')),
					h('div', { class: 'inp-card' }, h('strong', null, '3. Cada empresa, aislada'), h('span', { class: 'inp-muted' }, 'Nadie ve ni comparte con usuarios de otra empresa.')),
				),
			),
		].filter(Boolean))
	}

	function newCompany() {
		dialog('Nueva empresa', [
			{ name: 'name', label: 'Nombre de la empresa', required: true, placeholder: 'Ej: Constructora Andes' },
			{ name: 'initials', label: 'Sigla (2 o 3 letras)', placeholder: 'CA' },
			{
				name: 'preset', label: 'Plan', type: 'select', value: 'Pyme',
				options: PLANS.map((p) => ({ value: p.name, label: p.name + ' — ' + p.maxUsers + ' usuarios, ' + (p.quotaGB >= 1024 ? p.quotaGB / 1024 + ' TB' : p.quotaGB + ' GB') })).concat([{ value: '', label: 'Personalizado' }]),
				onchange: (val, inputs) => { const p = PLANS.find((x) => x.name === val); if (p) { inputs.maxUsers.value = p.maxUsers; inputs.quotaGB.value = p.quotaGB; inputs.plan.value = p.name } else { inputs.plan.value = ''; inputs.plan.focus() } },
			},
			{ name: 'plan', label: 'Nombre del plan', value: 'Pyme', required: true },
			{ name: 'maxUsers', label: 'Usuarios incluidos', type: 'number', min: 1, value: 3, required: true },
			{ name: 'quotaGB', label: 'Espacio (GB)', type: 'number', min: 1, value: 500, required: true },
			{ name: 'areas', label: 'Áreas (separadas por coma)', value: 'Administración, Proyectos, Plantillas', required: true },
			{ type: 'section', label: 'Administrador de la cuenta' },
			{ name: 'managerName', label: 'Nombre y apellido', required: true },
			{ name: 'managerEmail', label: 'Correo', type: 'email', required: true },
			{ name: 'managerPassword', label: 'Contraseña inicial (opcional)', type: 'password', autocomplete: 'new-password', help: 'Si la dejas vacía, le llega un correo para crearla.' },
		], 'Crear empresa', async (v) => {
			const r = await api('/companies', 'POST', {
				name: v.name, initials: v.initials, plan: v.plan, maxUsers: +v.maxUsers, quotaGB: +v.quotaGB,
				areas: v.areas.split(','), managerName: v.managerName, managerEmail: v.managerEmail, managerPassword: v.managerPassword,
			})
			flash(r.warning || ('Empresa "' + v.name + '" creada.'), r.warning ? 'warn' : 'ok')
			await showCompany(r.company.id)
		})
	}

	function fail(e) {
		const R = root()
		if (R) R.innerHTML = '<div class="inp-notice inp-notice--error"></div>'
		if (R) R.firstChild.textContent = 'No se pudo cargar el panel: ' + e.message
	}

	async function start() {
		try {
			ME = await api('/me')
			if (ME.isAdmin) await showCompanies()
			else if (ME.company && ME.company.isManager) await showCompany(ME.company.id)
			else root().innerHTML = '<div class="inp-empty">Esta sección es solo para el administrador de la cuenta.</div>'
		} catch (e) { fail(e) }
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start)
	else start()
})()
